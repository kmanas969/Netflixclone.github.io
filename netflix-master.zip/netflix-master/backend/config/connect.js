const mongoose = require("mongoose");

const connectDB = async() => {
    try {
        const conn = await mongoose.connect("mongodb+srv://kmanas969:Manas2002@cluster0.wzw5qtb.mongodb.net/?retryWrites=true&w=majority",{
            useNewUrlParser: true,
            useUnifiedTopology: true,
        })
        console.log(`MongoDB connected: ${conn.connection.host}`);
    } catch (error) {
        console.log(`error: ${error.message}`);
    }
}

module.exports = connectDB