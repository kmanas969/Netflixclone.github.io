function validateForm() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("pass").value;

    if (!validateEmail(email)) {
        alert("Please enter a valid email address");
        return false;
    }

    if (!validatePassword(pass)) {
        return password.length >= 6;
        alert("Please enter a valid password");
        return false;
    }
     // Check if both email and password fields are filled
    return true; // Form will be submitted if both fields are valid
}

function validateEmail(email) {
    var regex = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    return regex.test(email);
}

function validatePassword(pass) {
    // You can add your password validation logic here
    return password.length >= 6;
    return true;
   
};